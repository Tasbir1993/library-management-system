//
//  Bookissue.swift
//  libarary management project
//
//  Created by Sarb Maan on 2017-10-14.
//  Copyright © 2017 sarbjit. All rights reserved.
//

import Foundation



class Bookissue{
    public private(set) var BookissueNo:[Int] = []
   public private(set) var dateIssue:[String] = []
    public private(set) var dateReturn:[String] = []
    public private(set) var dateBookRetuned:[String] = []
    public private(set) var bookreturnedStatus:[String] = []
    var actionindex : Int = 0
    
    var action : String = ""
    
    init(BoIsuNO:[Int],DIssue:[String],Dreturn:[String],daBokRerurned:[String],BookreturnedStatus:[String]) {
        BookissueNo = BoIsuNO
        dateIssue = DIssue
        dateReturn = Dreturn
        dateBookRetuned = daBokRerurned
       bookreturnedStatus = BookreturnedStatus
      
    }
    func getbookissuenumber(actionindex: Int) -> Int {
        return BookissueNo[actionindex]
    }
    
    func getdateIssue(actionindex: Int) -> String {
        return dateIssue[actionindex]
    }
    
    func getdateReturen(actionindex: Int) -> String {
        return dateReturn[actionindex]
    }
    func getdatebookreturned(actionindex: Int) -> String {
        return dateBookRetuned[actionindex]
    }
    func getbookStatus(actionindex: Int) ->String {
        return bookreturnedStatus[actionindex]
    }
    
    
    
    
    func setdateissue(action : String)  {
        dateIssue.append(action)
    }
    func setdatereturn(action : String) {
        dateReturn.append(action)
    }
    func setdatereturened(action : String) {
        dateReturn.append(action)
    }
    func setdatereturnedbook(action : String) {
        dateBookRetuned.append(action)
    }
    func setbookreturnedstatus(action : String)  {
        self.bookreturnedStatus.append(action)
    }
    
    
}









