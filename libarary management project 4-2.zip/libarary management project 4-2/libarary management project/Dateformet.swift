//
//  Dateformet.swift
//  libarary management project
//
//  Created by sarbjit on 11/10/17.
//  Copyright © 2017 sarbjit. All rights reserved.
//

import Foundation
class Dateformet{
    static let dateFormatter = DateFormatter()
    static let dateFormat = "yyyy-MM-dd"
    static func convertStringToDate(stringDate: String) -> NSData{
        if stringDate == " " {
            return NSData()
        }
         dateFormatter.dateFormat = dateFormat
        return dateFormatter.dateFormat(from:stringDate) as NSData
    }
    static func convertDateToString(_ date: NSDate) -> String{
        dateFormatter.string(from: date as Date )
    }
}
