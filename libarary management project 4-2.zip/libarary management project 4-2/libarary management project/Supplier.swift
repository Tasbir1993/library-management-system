//
//  Supplier.swift
//  libarary management project
//
//  Created by sarbjit on 11/10/17.
//  Copyright © 2017 sarbjit. All rights reserved.
//

import Foundation

class Supplier{
    public private(set) var supplierId:[Int] = []
    public private(set) var supplierName:[String] = []
    public private(set) var supplierAddress:[String] = []
    public private(set) var suppliercontact:[String] = []
    var actionindex : Int = 0
    
    var action : String = ""
    init(suId:[Int] , suName:[String] , suAdress:[String] , suContact:[String]) {
        supplierId = suId
        supplierName = suName
        supplierAddress = suAdress
        suppliercontact = suContact
        
    }
    
    func getsuId(actionindex: Int) -> Int {
        return supplierId[actionindex]
    }
    func getsuName(actionindex: Int) -> String {
        return supplierName[actionindex]
    }
    func getsuaddress(actionindex: Int) -> String {
        return supplierAddress[actionindex]
    }
    func getsucontect(actionindex: Int) -> String {
        return suppliercontact[actionindex]
}
    func setsuname(action : String){
        supplierName.append(action)
        
    }
    func setsuaddress(action : String){
        supplierAddress.append(action)
        
    }
    func setsucontact(action : String){
        suppliercontact.append(action)
        
    }
}
