//
//  main.swift
//  libarary management project
//
//  Created by sarbjit on 11/10/17.
//  Copyright © 2017 sarbjit. All rights reserved.
//

import Foundation




var supplier = Supplier(suId: [1,2,3], suName: ["waheguru","satnam","mandeepSingh"], suAdress: ["brampton","brampton","brampton"], suContact: ["9877653","73547634","56674445"])


//print("-------------------------------------------------")




var bookdetail = Bookdetail(bookco: [1,2,3,4],bookname:["data stucture","dataminiing","networking","punjab history"],Bookcatego:[" \t computer"," \t computer"," \t computer","computer"], bookAu: ["raspal singh","raspal singh","raspal singh","marcos bittencourt"] , bookpub:["partaj singh","pertaj singh","partaj singh","sukhpal"] , bookpubDate:["12-12-2016","01-02-2015","07-01-2017",""], Bookrate:["$200.0","$200.0","$400.0","$500.0"])
print("1.Display book id,book name,category of book,book auther?")

print("BookID\t BookName \t\t categoryOfBook\t\t\t bookAuther ")
//reprt
for i in bookdetail.BookCode{
    print(bookdetail.getBcode(actionindex: i-1),"\t",bookdetail.getBname(actionindex: i-1),"\t\t\t",bookdetail.getcategory(actionindex: i-1),"\t\t",bookdetail.getAuther(actionindex: i-1))
}

//print("--------------------------Members Detail--------------------------------------")

//print("memberId \t\t memberNmae \t\t memberCity \t\t memeberStatus")
//print("------------------------------------------------------------------------------")
var members = Memberdetail(mId: [1,2,3,4,5],mName:["sarbjit","mandeep","tasbir"," kewal","kulwindre"],cityMem:["brampton","brampton","brampton","brampton","brampton"],tatus:["permanent","permanent","permanent","permanent","temporary"])



//print("------------------------------Fine----------------------------------------------")


print("--------------------------------------------------------------------------------")
var fine = Fine(fineN: [1,2,3,4,5], fineSta: ["no","no","\t no","\t no","no"],  FAmount: ["$0","$10","$20","$30"])

//report2
print("Report 2: members and their fine status.")
print("membername \t\t finestatus")
for i in fine.finenumber{
    print(members.getMname(actionindex: i-1),"\t\t",(fine.getfinestaus(actionindex: i-1)))
   
}
//print("---------------------------------------book issue table----------------------------------------------------------------")
//print("Book_issue_Number \t\t issue_date \t\t return_date \t\t returned_status \t\t book_returned  \t\t status ")
//print("---------------------------------------------------------------------------------------------------------------")
var bookissue = Bookissue(BoIsuNO:[1,2,3,4,5],DIssue:["20-01-2017","25-01-2017","29-01-2017","12-02-2017","22-03-2017"],Dreturn:["27-01-2017","02-02-2017","07-02-2017","18-02-2017","29-03-2017",],daBokRerurned:["25-01-2017","30-01-2017","12-02-2017","18-02-2017","29-03-2017"],BookreturnedStatus:["Yes","yes","yes","yes","yes"])

print("--------------------------------------------------------------------------------")

print("3.Display the book name issued on particular date ?")
print("book_name \t\t date_of_issue")


for i in bookissue.BookissueNo{
    if (bookissue.getbookissuenumber(actionindex:i-1)) == 1{
        
    print(bookdetail.getBname(actionindex: 2),"\t\t",bookissue.getdateIssue(actionindex: 3))
}
}
print("--------------------------------------------------------------------------------")

print("4.Display the total number of ‘computer’ books avaliable in the library")
var number = bookdetail.BookCode
var i = 0
while i < number.count {
    i = i + 1
    
}
print("count \t category")
print(i ,"\t",bookdetail.getcategory(actionindex: 1))
print("--------------------------------------------------------------------------------")

print("5.Display membership type and total members with that particular membership status")

var perma  = members.MemberId
var a = 0
while a < perma.count{
    a = a + 1
}

print("")
print("countofpermanentstatus \t permanent status")

print(a,"\t\t\t\t\t\t",members.getstatusofmembet(actionindex: 1))
print("")

